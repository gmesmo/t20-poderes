// src/components/Card.tsx
import { JSX } from 'react'
import { Poder, RequisitoExpressao, RequisitoBase } from '../../types/poderes' // Importa todos os tipos necessários

import styles from './styles.module.scss' // Importa os estilos do Card

// Funções auxiliares para exibir requisitos (coloque-as aqui ou em um arquivo de utilitários)
const formatarRequisitoBase = (req: RequisitoBase): JSX.Element => {
  if (req.tipo === 'atributo') {
    return <div>{`${req.nome} ${req.valor}`}</div>
  }
  if (req.tipo === 'pericia') {
    return (
      <div>{`${req.nome} ${req.treinado ? 'Treinado' : 'Não Treinado'}`}</div>
    )
  }
  if (req.tipo === 'nivel') {
    return <div>{`Nível ${req.valor}`}</div>
  }
  return <></>
}

const gerarTextoRequisitos = (expressao: RequisitoExpressao): JSX.Element => {
  if (Array.isArray(expressao)) {
    const partes = expressao.map(gerarTextoRequisitos)
    return <div>({partes.join(' E ')})</div>
  } else if ('OR' in expressao) {
    const partes = expressao.OR.map(gerarTextoRequisitos)
    return <div>({partes.join(' OU ')})</div>
  } else {
    return formatarRequisitoBase(expressao)
  }
}

interface CardProps {
  poder: Poder // Agora o Card recebe um objeto Poder completo
}

function gerarNomeTipo(tipo: string): string {
  switch (tipo) {
    case 'Poder Concedido':
      return 'PoderConcedido'
    default:
      return tipo
  }
}

function Card({ poder }: CardProps) {
  const { nome, subtitulo, tipo, requisitos, texto, ref } = poder

  return (
    <div className={styles.card}>
      <div
        className={`${styles.titulo} ${
          styles[`tipo-${gerarNomeTipo(tipo || '')}`]
        } ${!subtitulo && styles.semSubtitulo}`}
      >
        {nome}
        {subtitulo && <h4 className={styles.subtitulo}>{subtitulo}</h4>}
      </div>
      <div className={styles.content}>
        {/* Exibe o tipo do poder, se desejar */}
        {tipo && (
          <p className='tipo-poder'>
            Poder {tipo === 'Poder Concedido' ? 'Concedido' : `de ${tipo}`}
          </p>
        )}
        {requisitos && (
          <p className='requisito'>
            <strong>Requer:</strong> {gerarTextoRequisitos(requisitos)}
          </p>
        )}
        <p>{texto}</p>
      </div>
      <p className={styles.ref}>
        <strong>Referência:</strong> {ref.Manual} p. {ref.pagina}
      </p>
    </div>
  )
}

export default Card
